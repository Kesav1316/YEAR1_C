/******************************************************************************

Experiment 4 : Reverse String

*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <stdbool.h>

void reverse_string(char *str_pt){
    /* CASE SENSITIVE
    Input : "Martin "
    Output: " nitraM"
    */
    // 2) Your CODE goes here
    
    
    
    // Within this 
}


int main() 
{ 
    char str_input[50];
    char *str_ptr;
    
    // 1) Get input from user and store it in str_input and store its address in str_ptr  
    // YOUR CODE GOES HERE 
    
    
    
    // TILL HERE
    printf("Orignal String  - %s\n", str_input);
    reverse_string(str_ptr);
    printf("Reversed string - %s\n", str_input);
    return 0; 
}
