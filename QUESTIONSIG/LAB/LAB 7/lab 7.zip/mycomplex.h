/*******************************************************************************

                Your Custom Header file for Complex arithmetic

*******************************************************************************/
// Edit this file by adding all the functions from LAB 5

// Structure to store the data
struct Complex
{
  float real, imag;
};

typedef struct Complex complex;